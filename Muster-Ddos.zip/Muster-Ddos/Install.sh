
echo " _   _ _  _    ____ _  _______ ____    ___ _____   ________  _   _ _____ 
| | | | || |  / ___| |/ /___ /|  _ \  |_ _|_   _| |__  / _ \| \ | | ____|
| |_| | || |_| |   | ' /  |_ \| |_) |  | |  | |     / / | | |  \| |  _|  
|  _  |__   _| |___| . \ ___) |  _ <   | |  | |    / /| |_| | |\  | |___ 
|_| |_|  |_|  \____|_|\_\____/|_| \_\ |___| |_|   /____\___/|_| \_|_____|
                                                                         
--------------------------Bangladesh Syber Pro--------------------------"
echo "Start Prosess"
sudo apt-get update && apt-get upgrade
sudo cd
sudo apt -y upgrade
sudo python -V
sudo python3 -V
sudo apt update
sudo apt install python-pip
sudo pip2 --version
sudo pip --version
sudo apt update
sudo pip3 --version
sudo pip2 install --user awscli
sudo pip3 install --user awscli
sudo env | grep PATH
pip2 show awscli
echo "--Complite The Prosess--"
echo "-----H4CK3R IT ZONE------"
echo "ALL IS OK READY TO ATTACK"

======================================================

H4CK3R IT ZONE 	ONLY PROVIDE BY EDUCATION PROPOSS ONLY

======================================================

At fast install pip3

$ bash Install.sh






----------------------
$ cd Muster-Ddos
$ chmod +x Muster-Ddos.py
$ python3 Muster-Ddos.py

------------------------------------------------------
H4CK3R IT ZONE
https://www.youtube.com/channel/UCcaCMB_QkshPcFpl-PgoNZg
------------------------------------------------------
if you learn ethicall hacking Subscribe our chanell and 
join my facebook grup/page

if you like this video pillage share to your friend sharing do not bad 
if you share this video can learning to your friends

My Facebook 
my page https://web.facebook.com/Hackeritzonebangladeshsyberpro/?modal=admin_todo_tour
my grup https://web.facebook.com/groups/1566066986878847/
--------------------------------------------------------

